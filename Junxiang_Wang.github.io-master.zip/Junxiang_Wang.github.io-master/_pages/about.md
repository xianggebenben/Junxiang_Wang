---
layout: about
title: About
permalink: /
subtitle: <a href='https://www.nec-labs.com/'>NEC Laboratories America</a>.

profile:
  align: right
  image: profile.jpg
  image_circular: false # crops the image to make it circular

news: true  # includes a list of news items
latest_posts: false  # includes a list of the newest posts
selected_papers: true # includes a list of papers marked as "selected={true}"
social: true  # includes social icons at the bottom of the page
---

Junxiang Wang is a researcher at NEC Laboratories America. He received the Ph.D. degree from the Department of Computer Science at Emory University in 2022. Before that, he received his Master’s degree and Bachelor’s degree from George Mason University in 2020 and East China Normal University in 2012, respectively. His research interests include data mining in social media, inverse problems on graphs, and nonconvex optimization in deep learning. He has published various research papers in top-tier conferences and journals such as KDD, ICDM, WWW, AAAI, Proceedings of the IEEE, and TNNLS. He has been invited to present his works in several optimization conferences.

[Google Scholar](https://scholar.google.com/citations?user=UBFTZbAAAAAJ&hl=en)
