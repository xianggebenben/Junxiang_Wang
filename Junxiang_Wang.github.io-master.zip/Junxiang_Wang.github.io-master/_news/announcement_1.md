---
layout: post
date: 2022-11-15 23:00:00-0400
inline: true
related_posts: false
---

I passed the dissertation defense. Officially Dr. Wang!
