---
layout: post
date: 2022-12-30 23:00:00-0400
inline: true
related_posts: false
---
One paper is accepted by SDM 2023.
