Matlab code for Multi-task Learning frameworkwith Uncertainty Estimation (MLUE)

Junxiang Wang, Yuyang Gao, Andreas Z�ufle, Jingyuan Yang and Liang Zhao.
Incomplete Label Uncertainty Estimation for Petition Victory Prediction with Dynamic Features. 
International Conference on Data Mining(ICDM 2018)

 @misc{Wang2018,
    author  = "Junxiang Wang, Yuyang Gao, Andreas Zufle, Jingyuan Yang and Liang Zhao",
    title   = "Incomplete Label Uncertainty Estimation for Petition Victory Prediction with Dynamic Features",
    conference = "Proceedings of International Conference on Data Mining",
    year    = "2018",
    month   = "nov"
}

Run main.m on Matlab (version R2016a later is recommended).

Feel free to contact Junxiang Wang(jwang40@gmu.edu) if you have any questions.