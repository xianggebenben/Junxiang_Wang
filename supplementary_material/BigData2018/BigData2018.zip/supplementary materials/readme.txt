Matlab code for nonsmooth Semi-supervised Multi-instance learning model(nSSM) 

Junxiang Wang, Liang Zhao and Yanfang Ye.
Semi-supervised Multi-instance Interpretable Models for Flu Shot Adverse Event Detection
International Conference on Big Data(BigData 2018)

 @misc{WangBigData2018,
    author  = "Junxiang Wang, Liang Zhao and Yanfang Ye",
    title   = "Semi-supervised Multi-instance Interpretable Models for Flu Shot Adverse Event Detection",
    conference = "Proceedings of International Conference on Big Data",
    year    = "2018",
    month   = "dec"
}

Run CV.m on Matlab (version R2016a later is recommended).

Feel free to contact Junxiang Wang(jwang40@gmu.edu) if you have any questions.