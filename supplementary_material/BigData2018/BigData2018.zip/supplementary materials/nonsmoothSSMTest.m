function [CM,AUC,ROCX,ROCY,AUPR,PRX,PRY]=nonsmoothSSMTest(beta,test,testInstanceIndex,testLabel)
% test L1 regularized  nonsmooth semi-supervised multi-instance model(nSSM)
% beta: 1*(k+1) vector, the objective parameter.
% test: n* k matrix, the test Twitter data.
% testInstanceIndex: n*1 vector, the mapping from tweets to test users.
% testLabel: t*1 vector, the labels of test users.

% where:
% n: number of test Tweets.
% k: number of keywords.
% t: number of test users.

% return:
% CM: 2*2 matrix, confusion matrix.
% AUC: the area under ROC curve.
% ROCX: 1 vector, the X axis of ROC curve.
% ROCY: 1 vector, the Y axis of ROC curve.
% AUPR: the area under PR curve.
% PRX: 1 vector, the X axis of PR curve.
% PRY: 1 vector, the Y axis of PR curve.
l = length(testLabel);
k = size(test,2);
test =[ones(size(test,1),1),test];
S=test*beta';
maxS=zeros(l,1);
maxInstance=zeros(l,k+1);
for i=1:l
    index = find(testInstanceIndex==i);
    if ~isempty(index)
        [maxS(i),pos]=max(S(index));
        maxInstance(i,:) =test(index(pos),:);
    else
        maxS(i)=beta(1);
        maxInstance(i,:) =[1,zeros(1,k)];
    end
end
CM=confusionmat(testLabel,(maxS>=0)*1);
[ROCX,ROCY,~,AUC]=perfcurve(testLabel,1./(1+exp(-maxS)),1);
[PRX,PRY,~,AUPR]=perfcurve(testLabel,1./(1+exp(-maxS)),1,'xCrit', 'reca', 'yCrit', 'prec');
end