% references: Semi-supervised Multi-instance Interpretable Models for Flu Shot Adverse Event Detection
% Junxiang Wang, Liang Zhao, and Yanfang Ye 2018 IEEE International Conference on Big Data (BigData 2018)
%@misc{WangBigData2018,
%    author  = "Junxiang Wang, Liang Zhao and Yanfang Ye",
%    title   = "Semi-supervised Multi-instance Interpretable Models for Flu Shot Adverse Event Detection",
%    conference = "Proceedings of International Conference on Big Data",
%    year    = "2018",
%    month   = "dec"
%}
% contact Junxiang Wang(jwang40.gmu.edu)
clear;
% The dataset consists of the following components:
% data: n*k matrix, labeled Twitter data.
% InstanceIndex: n*1 vector, the mapping from tweets to labeled users.
% label: u*1 vector, the label of users: 1 means positive and 0 means
% negative.
% unlabel: m*k matrix, unlabeled Twitter data.
% unlabellnstanceIndex: m*1 vector, the mapping from tweets to unlabeled
% users.
% where
%n: number of Tweets from labeled users.
%m: number of Tweets from unlabeled users.
%k: number of keywords.
%u: the number of labeled users.
load data.mat;
rho =1;
nu =1;
lambda = 1;
% 5-fold cross validation
nfold=5;
rng('default');
indices = crossvalind('Kfold', length(label), nfold);
beta=zeros(1,size(data,2)+1);
m=max(unlabelInstanceIndex);
% forming training set and test set
for i=1:nfold
    i
    testIdx = find(indices == i);
    trainIdx = find(indices ~= i);
    train=[];
    trainInstanceIndex=[];
    for j=1:length(trainIdx)
        index=find(InstanceIndex==trainIdx(j));
        train=[train;data(index,:)];
        trainInstanceIndex=[trainInstanceIndex;j*ones(length(index),1)];
    end
    test=[];
    testInstanceIndex=[];
    for j=1:length(testIdx)
        index=find(InstanceIndex==testIdx(j));
        test=[test;data(index,:)];
        testInstanceIndex=[testInstanceIndex;j*ones(length(index),1)];
    end
    n=length(trainIdx);
% beta: a 1*(k+1) vector, the first element is the intercept while the
% remaining is weights of keywords.
% training nSSM model
[~,~,~,beta,~] =nonsmoothSSM(train,unlabel,trainInstanceIndex,unlabelInstanceIndex,label(trainIdx),rho,nu,lambda,n,m,beta);
% testing model
% CM:confusion matrix
% auc: area under ROC curve
% aupr: area under PR curve
[CM,auc(i),ROCX{i},ROCY{i},aupr(i),PRX{i},PRY{i}]=nonsmoothSSMTest(beta,test,testInstanceIndex,label(testIdx));
% acc: accuracy
% pr: precision
% re: recall
% fs: F-score
acc(i)=(CM(1,1)+CM(2,2))/sum(sum(CM));
pr(i)=CM(2,2)/sum(CM(:,2));
re(i)=CM(2,2)/sum(CM(2,:));
fs(i)=2*pr(i)*re(i)/(pr(i)+re(i));
end