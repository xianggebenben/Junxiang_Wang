Matlab code for Mulit-instance Domain Adaptation (MIDA)

Junxiang Wang, Liang Zhao. 
Multi-instance Domain Adaptation for Vaccine Adverse Event Detection.
27th International World Wide Web Conference (WWW 2018)

@misc {Wang2018,
    author  = "Junxiang Wang, Liang Zhao",
    title   = "Multi-instance Domain Adaptation for Vaccine Adverse Event Detection",
    conference = "Proceedings of 27th International World Wide Web Conference",
    year    = "2018",
    month   = "apr"
}

Run main.m on Matlab (version R2016a later is recommended).

Feel free to contact Junxiang Wang(jwang40@gmu.edu) if you have any questions.